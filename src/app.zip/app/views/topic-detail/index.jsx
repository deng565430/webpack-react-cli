import React from 'react'

export default class ToplicDetail extends React.Component {
  componentDidMount() {
    // do somethings
  }
  render() {
    return (
      <div>
        ToplicDetailddd
      </div>
    )
  }
}
